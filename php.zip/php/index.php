<?php
include("connection.php");

if(isset($_POST['submit']))
{
	
	$name= $_POST['name'];
	$pass=$_POST['pass'];
	$subject=$_POST['subject'];
	
	$query= "insert into abc (name,pass,subject) VALUES ('$name','$pass','$subject')";
	$check = mysqli_query($con,$query) or die (mysqli_error($con));
	
	
	if($check)
		
		{
			
			echo "success";
		}
		else{
			
			echo "error";
		}
}

?>
<!Doctype HTML>
<html>
<head>
	
	<title> Student Registration </title>
	
	<style>
		h2
		{
			font-size:18px;
			color:green;
		}
		
		.abc
		{
			color:red;
		}
		
	</style>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

</head>

<body>
<form method="post" action="">
	<table border="1" align="center" style="border-collapse:collapse;" cellpadding="5px">
		<tr>
			<th colspan="2"> <h2> Student't Registration Form </h2> </th>
		</tr>
		
		<tr>
			<td> User Name </td>
			<td> <input type="text" id="name" name="name" />  </td>
		</tr>
		
		<tr>
			<td> Password </td>
			<td> <input type="password" id="pass" name="pass" />  </td>
		</tr>
		
		<tr>
			<td> Subject </td>
			<td> <input type="text" id="subject" name="subject" /> </td> 
		</tr>
		
		<tr>
			<td colspan="2" align="center"> 
		     	<button type="submit" id="submit" name="submit" value="Submit" > Submit </button>
			</td>
		</tr>
		
	</table>
</form>


</body>
</html> 