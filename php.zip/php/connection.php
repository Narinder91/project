<?php
$host="localhost";
$username="root";
$password="";
$dbname="php";


$con=mysqli_connect("localhost","root","","user");

if(!$con){
	
	echo "connection" .mysqli_error($con);
}
?>